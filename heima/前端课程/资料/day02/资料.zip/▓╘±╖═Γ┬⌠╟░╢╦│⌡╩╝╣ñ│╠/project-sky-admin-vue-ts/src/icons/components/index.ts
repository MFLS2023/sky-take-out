/* tslint:disable */
import './main'
import './employee'
import './pay'
import './shop'
import './vip'
import './hamburger'
import './dashboard'
import './inform'
