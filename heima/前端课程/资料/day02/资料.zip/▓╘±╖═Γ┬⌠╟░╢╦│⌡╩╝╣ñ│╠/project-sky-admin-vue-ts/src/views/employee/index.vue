<template>
  <div class="dashboard-container">
    <div class="container">

    </div>

  </div>
</template>
<script lang="ts">

export default  {
  
}
</script>

<style lang="scss" scoped>
.disabled-text {
  color: #bac0cd !important;
}
</style>
